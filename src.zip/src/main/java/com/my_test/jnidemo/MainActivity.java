package com.my_test.jnidemo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends Activity {
    public int num = 10;
    public static String name = "suci";
    private int age = 21;
    private String sex = "female";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        // Example of a call to a native method
        final  TextView tv = (TextView) findViewById(R.id.TextView01);
        Button button = (Button)findViewById(R.id.Button01);
        final EditText editText = (EditText) findViewById(R.id.EditText01);
        editText.setHint("请输入");
        Log.d("JniDemo", "调用前: num=" + num);
        Log.d("JniDemo", "调用前: name=" + name);
        Log.d("JniDemo", "调用前: age=" + age);
        Log.d("JniDemo", "调用前: sex=" + sex);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tv.setText(stringFromJNI(editText.getText().toString()));
                Log.d("JniDemo", "调用后: num=" + addNum());
                accessStaticField();
                Log.d("JniDemo", "调用后: name=" + name);
                accessPrivateField();
                Log.d("JniDemo", "调用后: age=" + age);
                accessPublicMethod();
                Log.d("JniDemo", "调用后: sex=" + sex);
                accessStaticMethod();
                Log.d("JniDemo", "调用后: name=" + name);
                MethodJni methodJni = new MethodJni();
                String retName = methodJni.accessSuperMethod();
                Log.d("JniDemo", "调用父类: hello(name) " + retName);
                int arr[] = {1,2,3,4,5};
                int sum = intArrayMethod(arr);
                Log.d("JniDemo","sum= " + sum);
                Log.d("JniDemo","objectMethod:"+ objectMethod(new Person()).toString() + "");
                String hello = new DynamicRegisterJni().getStringFromCpp();
                Log.d("JniDemo", hello);
                ArrayList<Person> personList = new ArrayList<Person>();
                Person person;
                for (int i=0;i<3;i++)
                {
                    person = new Person();
                    person.setName("wyw");
                    person.setAge(10+i);
                    personList.add(person);
                }
                Log.d("JniDemo", "调用前: java list=" + personList.toString());
                Log.d("JniDemo", "调用后: java list=" + personArrayListMethod(personList).toString());
            }
        });
        Button button1 = (Button)findViewById(R.id.Button02);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(MainActivity.this, Activity01.class);
                startActivity(intent);
                MainActivity.this.finish();
            }
        });
        Button button2 = (Button)findViewById(R.id.Button03);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(MainActivity.this, Activity02.class);
                startActivity(intent);
                MainActivity.this.finish();
            }
        });
    }
    public void setSex(String sex)
    {
        this.sex = sex;
    }
    public String getSex()
    {
        return sex;
    }
    public static void setName(String inputName)
    {
        name = inputName;
    }

    /**
     * A native method that is implemented by the 'native-lib' native library,
     * which is packaged with this application.
     */
    public native String stringFromJNI(String str);
    public native int addNum();
    public native void accessStaticField();
    public native void accessPrivateField();
    public native void accessPublicMethod();
    public native void accessStaticMethod();
    public native int intArrayMethod(int[] arr);
    public native Person objectMethod(Person person);
    public native ArrayList<Person> personArrayListMethod(ArrayList<Person> persons);

    // Used to load the 'native-lib' library on application startup.
    static {
        //System.loadLibrary("native-lib");
        System.loadLibrary("libandroid_sm_cipher");
    }
}
