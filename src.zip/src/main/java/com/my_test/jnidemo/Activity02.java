package com.my_test.jnidemo;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

/**
 * Created by HP on 2019/6/26.
 */

public class Activity02 extends Activity {
    private WebView mWebView;
    private PersonalData mPersonalData;
    @android.webkit.JavascriptInterface
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity02_layout);

        mPersonalData = new PersonalData();
        mWebView = (WebView)this.findViewById(R.id.WebView01);
        mWebView.getSettings().setJavaScriptEnabled(true);

        mWebView.addJavascriptInterface(this, "PersonalData");
        mWebView.loadUrl("file:///mnt/shared/Other/PersonalData.html");
    }
    public PersonalData getPersonalData()
    {
        return mPersonalData;
    }
    class PersonalData
    {
        String  mID;
        String  mName;
        String  mAge;
        String  mBlog;
        public PersonalData()
        {
            this.mID="123456789";
            this.mName="Android";
            this.mAge="100";
            this.mBlog="http://yarin.javaeye.com";
        }
        public String getID()
        {
            return mID;
        }
        public String getName()
        {
            return mName;
        }
        public String getAge()
        {
            return mAge;
        }
        public String getBlog()
        {
            return mBlog;
        }
    }
}
