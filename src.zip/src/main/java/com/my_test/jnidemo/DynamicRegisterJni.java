package com.my_test.jnidemo;

/**
 * Created by HP on 2019/6/28.
 */

public class DynamicRegisterJni {
    public native String getStringFromCpp();
}
