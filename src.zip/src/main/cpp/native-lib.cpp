#include <jni.h>
#include <string>
#include "android/log.h"

#ifndef LOG_TAG
#define LOG_TAG "JNI_LOG"
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG,LOG_TAG,__VA_ARGS__)
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,LOG_TAG,__VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN,LOG_TAG,__VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR,LOG_TAG,__VA_ARGS__)
#define LOGF(...) __android_log_print(ANDROID_LOG_FATAL,LOG_TAG,__VA_ARGS__)
#endif

static const char *className = "com/my_test/jnidemo/DynamicRegisterJni";
#ifdef __cplusplus
extern "C" {
#endif

JNIEXPORT jstring JNICALL
Java_com_my_1test_jnidemo_MainActivity_stringFromJNI(
        JNIEnv *env,
        jobject jobj,  /*this*/ jstring strParam) {
    std::string hello = "Hello from C++";
    const char *str = env->GetStringUTFChars(strParam, NULL);
    std::string ret = str;
    env->ReleaseStringUTFChars(strParam, str);

    return env->NewStringUTF(ret.c_str());
}

JNIEXPORT jint JNICALL
Java_com_my_1test_jnidemo_MainActivity_addNum(
        JNIEnv *env,
        jobject jobj) {
    jclass jclazz = env->GetObjectClass(jobj);
    jfieldID fid = env->GetFieldID(jclazz, "num", "I");
    jint num = env->GetIntField(jobj, fid);

    num++;

    return num;
}
JNIEXPORT void JNICALL
Java_com_my_1test_jnidemo_MainActivity_accessStaticField(
        JNIEnv *env,
        jobject jobj)
{
    jclass jclazz = env->GetObjectClass(jobj);
    jfieldID fid  = env->GetStaticFieldID(jclazz, "name", "Ljava/lang/String;");
    jstring  name = (jstring)env->GetStaticObjectField(jclazz, fid);
    const char* str = env->GetStringUTFChars(name, JNI_FALSE);
    std::string ret = "hello ";
    ret.append(str);
    jstring new_ret = env->NewStringUTF(ret.c_str());
    env->SetStaticObjectField(jclazz, fid, new_ret);
}
JNIEXPORT void JNICALL
Java_com_my_1test_jnidemo_MainActivity_accessPrivateField(
        JNIEnv *env,
        jobject jobj)
{
    jclass jclazz = env->GetObjectClass(jobj);
    jfieldID fid  = env->GetFieldID(jclazz, "age", "I");
    jint     age  = env->GetIntField(jobj, fid);
    if (age > 18)
    {
        age = 18;
    } else
    {
        age--;
    }
    env->SetIntField(jobj, fid, age);
}

JNIEXPORT void JNICALL
Java_com_my_1test_jnidemo_MainActivity_accessPublicMethod(
        JNIEnv *env,
        jobject jobj)
{
    jclass jclazz = env->GetObjectClass(jobj);
    jmethodID mid = env->GetMethodID(jclazz, "setSex", "(Ljava/lang/String;)V");
    char c[10] = "male";
    jstring jsex = env->NewStringUTF(c);
    env->CallVoidMethod(jobj, mid, jsex);
}

JNIEXPORT void JNICALL
Java_com_my_1test_jnidemo_MainActivity_accessStaticMethod(
        JNIEnv *env,
        jobject jobj)
{
    jclass jclazz = env->GetObjectClass(jobj);
    jmethodID mid = env->GetStaticMethodID(jclazz, "setName", "(Ljava/lang/String;)V");
    char c[10] = "male11";
    jstring jname = env->NewStringUTF(c);
    env->CallStaticVoidMethod(jclazz, mid, jname);
}

JNIEXPORT jstring JNICALL
Java_com_my_1test_jnidemo_MethodJni_accessSuperMethod(
        JNIEnv *env,
        jobject jobj)
{
    jclass jclazz = env->FindClass("com/my_test/jnidemo/SuperJni");
    if (jclazz == NULL)
    {
        char c[] = "error";
        return env->NewStringUTF(c);
    }
    jmethodID mid = env->GetMethodID(jclazz, "hello", "(Ljava/lang/String;)Ljava/lang/String;");
    char c[10] = "male11";
    jstring jname = env->NewStringUTF(c);
    return (jstring)env->CallNonvirtualObjectMethod(jobj, jclazz, mid, jname);
}
JNIEXPORT jint JNICALL
Java_com_my_1test_jnidemo_MainActivity_intArrayMethod(
        JNIEnv *env,
        jobject jobj, jintArray arr_)
{
    jint len = 0, sum = 0;
    jint *arr = env->GetIntArrayElements(arr_, 0);
    len = env->GetArrayLength(arr_);
    jint i = 0;
    for (; i<len;i++)
    {
        sum += arr[i];
    }
    env->ReleaseIntArrayElements(arr_, arr, 0);

    return sum;
}
JNIEXPORT jobject JNICALL
Java_com_my_1test_jnidemo_MainActivity_objectMethod(
        JNIEnv *env,
        jobject jobj, jobject person)
{
    jclass clazz = env->GetObjectClass(person);
    if (clazz == NULL){
        return env->NewStringUTF("cannot find class");
    }
    jmethodID mid = env->GetMethodID(clazz, "<init>", "(ILjava/lang/String;)V");

    if (mid == NULL)
    {
        return env->NewStringUTF("not find constructor method");
    }
    jstring name = env->NewStringUTF("cfanr");

    return env->NewObject(clazz, mid, 21, name);
}

JNIEXPORT jobject JNICALL
Java_com_my_1test_jnidemo_MainActivity_personArrayListMethod(
        JNIEnv *env,
        jobject jobj, jobject persons)
{
    jclass clazz = env->GetObjectClass(persons);
    if (clazz == NULL)
    {
        return env->NewStringUTF("not find class");
    }
    jmethodID constructMid = env->GetMethodID(clazz, "<init>", "()V");
    if (constructMid == NULL)
    {
        return env->NewStringUTF("not find constructormethod");
    }
    jmethodID addMid = env->GetMethodID(clazz, "add", "(Ljava/lang/Object;)Z");
    jclass personCls = env->FindClass("com/my_test/jnidemo/Person");
    jmethodID personMid = env->GetMethodID(personCls, "<init>", "(ILjava/lang/String;)V");

    jobject arrayList = env->NewObject(clazz, constructMid);

    jint i = 0;
    for (;i<3;i++)
    {
        jstring name = env->NewStringUTF("Native");
        jobject person = env->NewObject(personCls, personMid, 18+i, name);
        env->CallBooleanMethod(arrayList, addMid, person);
    }

    return arrayList;
}
/*
 * 动态注册
 * 先编写Java的native方法
 * 编写JNI函数的实现（函数名可以随便命名）
 * 利用结构体JNINativeMethod保存Java native方法和JNI函数对应关系
 * 利用registerNatives(JNIEnv* env)注册类的所有本地方法
 * 在JNI_OnLoad方法中调用注册方法
 * 在java中通过System.loadLibrary加载完JNI动态库之后，会自动调用JNI_OnLoad函数完成动态注册*/
static jstring sayHello(JNIEnv *env, jobject){
    LOGI("hello, this is native log.");
    const char *hello = "Hello from c++";
    return env->NewStringUTF(hello);
}
static JNINativeMethod jni_Methods_table[] = {
        {"getStringFromCpp", "()Ljava/lang/String;", (void*)sayHello},
};
static int registerNativeMethods(JNIEnv *env, const char *className, const JNINativeMethod *gMethods, int numMethods){
    jclass clazz;
    LOGI("Registering %s natives\n", className);
    clazz = env->FindClass(className);
    if (clazz == NULL){
        LOGE("Native registration unable to find class %s\n", className);
        return JNI_ERR;
    }
    if (env->RegisterNatives(clazz, gMethods, numMethods) < 0)
    {
        LOGE("Register natives failed for %s\n", className);
        return JNI_ERR;
    }
    env->DeleteLocalRef(clazz);
    return JNI_OK;
}
jint JNI_OnLoad(JavaVM *vm, void *reserved)
{
    LOGI("call JNI_OnLoad");
    JNIEnv *env = NULL;

    if (vm->GetEnv((void**)&env, JNI_VERSION_1_4) != JNI_OK)
    {
        return JNI_EVERSION;
    }

    registerNativeMethods(env, className, jni_Methods_table, sizeof(jni_Methods_table)/sizeof(JNINativeMethod));
    return JNI_VERSION_1_4;
}

JNIEXPORT void JNICALL
Java_com_my_1test_jnidemo_MainActivity_registerNatives(
        JNIEnv *env, jclass clazz){
    env->RegisterNatives(clazz, jni_Methods_table, sizeof(jni_Methods_table)/sizeof(JNINativeMethod));
}
#ifdef __cplusplus
}
#endif
